package com.example.myschool;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.icu.text.IDNA;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.file.FileVisitOption;

public class MainActivity extends AppCompatActivity {

    Button btn_login , btn_info ,btn_cal,btn_call;
    EditText edit_userid,edit_passwd;
    CheckBox chk_agree;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edit_userid = findViewById(R.id.edit_userid);
        edit_passwd = findViewById(R.id.edit_passwd);
        btn_login=findViewById(R.id.btn_login);
        btn_info=findViewById(R.id.btn_info);
        btn_cal=findViewById(R.id.btn_cal);
        btn_call=findViewById(R.id.btn_call);
        chk_agree=findViewById(R.id.chk_agree);

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userid = edit_userid.getText().toString();
                String passwd = edit_passwd.getText().toString();


                if(chk_agree.isChecked()==false) {
                    myToast("개인정보 수집에 동의해주세요.");
                    return;
                }

                if(userid.length()<5){
                    myToast("아이디는 5글자 이상입니다.");
                }else if(passwd.length()<6){
                    myToast("패스워드는 6글자 이상입니다.");
                }else{

                    if(userid.equals("30609") && passwd.equals("123456")){
                        myToast(userid+ "님 환영합니다.");
                    }else{
                        myToast("잘못된 로그인 정보입니다. 다시 입력해주세요.");
                    }

                }

                }


        });

        btn_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myToast("학과소개 화면이동");
                Intent intent = new Intent(MainActivity.this,InfoActivity.class);
                startActivity(intent);
            }
        });
    }

    void myToast(String msg){
        Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_SHORT).show();
    }
}
